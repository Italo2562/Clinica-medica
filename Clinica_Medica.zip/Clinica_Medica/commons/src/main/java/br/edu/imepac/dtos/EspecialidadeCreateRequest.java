package br.edu.imepac.dtos;

import lombok.Data;

@Data
public class EspecialidadeCreateRequest {
    private String nome;
}
