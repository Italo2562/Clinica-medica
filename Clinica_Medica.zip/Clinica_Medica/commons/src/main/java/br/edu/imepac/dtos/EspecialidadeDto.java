package br.edu.imepac.dtos;

import lombok.Data;

@Data
public class EspecialidadeDto {
    private Long id;
    private String nome;
}
